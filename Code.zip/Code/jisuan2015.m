%%Import matrix data and calculation
clear;clc;
X =xlsread('Carbon_2015.xlsx','Total input matrix','A2:AXB2');
C =xlsread('Carbon_2015.xlsx','Total carbon emission matrix','A3:AXB3');
B =xlsread('Carbon_2015.xlsx','Intermediate input matrix','C3:AXD1304');
I =eye(1302);
K=C./X*1000000
A=B./X
D=K*(I-A)^(-1)
%Code of writing
xlswrite('Carbon_2015.xlsx',D,4)
xlswrite('Carbon_2015.xlsx',K,5)
%Convert one row matrix of results to multirow matrix
D1=reshape(D,42,31)
xlswrite('Carbon_2015.xlsx',D1,6)